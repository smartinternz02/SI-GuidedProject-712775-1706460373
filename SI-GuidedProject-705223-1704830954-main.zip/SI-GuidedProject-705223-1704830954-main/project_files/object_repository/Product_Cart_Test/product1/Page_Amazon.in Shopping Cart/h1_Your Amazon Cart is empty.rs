<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Your Amazon Cart is empty</name>
   <tag></tag>
   <elementGuidId>d8eac8f1-540d-4337-8b6d-b0ca481505a1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1.a-spacing-mini.a-spacing-top-base</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sc-active-cart']/div/div/div/h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>020a09bf-6cc4-4e1d-b606-79baa2dda09e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-spacing-mini a-spacing-top-base</value>
      <webElementGuid>ac83b306-7ede-4f09-ac67-51015462edcd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                Your Amazon Cart is empty.
            </value>
      <webElementGuid>5d9790d3-f9d0-4741-88f0-3ecf355918fa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sc-active-cart&quot;)/div[@class=&quot;a-cardui-body a-scroller-none&quot;]/div[@class=&quot;a-row sc-cart-header sc-compact-bottom&quot;]/div[@class=&quot;a-row&quot;]/h1[@class=&quot;a-spacing-mini a-spacing-top-base&quot;]</value>
      <webElementGuid>4abc5ca2-764d-40bb-9951-991c6fd0efdd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sc-active-cart']/div/div/div/h1</value>
      <webElementGuid>438ac079-a1f6-4d84-a5df-fdd932eff199</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>e321d7c1-548e-4a35-b010-a4c6c0433d3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = '
                Your Amazon Cart is empty.
            ' or . = '
                Your Amazon Cart is empty.
            ')]</value>
      <webElementGuid>dc2859c6-5036-4c5d-a581-49c1bd42f817</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
