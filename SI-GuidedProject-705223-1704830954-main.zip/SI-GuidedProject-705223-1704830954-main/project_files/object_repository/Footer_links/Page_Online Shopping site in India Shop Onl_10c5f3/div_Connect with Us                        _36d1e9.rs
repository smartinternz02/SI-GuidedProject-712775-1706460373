<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Connect with Us                        _36d1e9</name>
   <tag></tag>
   <elementGuidId>d53d8d30-47d8-44af-a4cd-d08d5ab6666d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='navFooter']/div/div/div[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>f75b132a-b75f-41e4-89ce-76f258017fb6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>navFooterLinkCol navAccessibility</value>
      <webElementGuid>7200e9cb-424a-413a-8b5f-21f1a8ef7201</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
          Connect with Us
        
            
              Facebook
            
            
              Twitter
            
            
              Instagram
            
        
      </value>
      <webElementGuid>034052cb-3d6a-4fbc-bb0f-67d503fc40b2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navFooter&quot;)/div[@class=&quot;navFooterVerticalColumn navAccessibility&quot;]/div[@class=&quot;navFooterVerticalRow navAccessibility&quot;]/div[@class=&quot;navFooterLinkCol navAccessibility&quot;]</value>
      <webElementGuid>34a87eaa-b19a-470b-83ac-719cc846133e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='navFooter']/div/div/div[3]</value>
      <webElementGuid>3782dd84-d40b-4502-b689-a663fae16e92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/div[3]</value>
      <webElementGuid>1c8f0197-ccdf-41ee-a24e-72952ecb1dbb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
          Connect with Us
        
            
              Facebook
            
            
              Twitter
            
            
              Instagram
            
        
      ' or . = '
          Connect with Us
        
            
              Facebook
            
            
              Twitter
            
            
              Instagram
            
        
      ')]</value>
      <webElementGuid>a46b0a12-cd8a-4594-ac0e-5214b3e479f6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
